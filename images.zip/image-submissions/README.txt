Cloudfront url: https://d1aodyntmd0xnj.cloudfront.net

S3 Bucket url: http://udacity-cloud-fpbucket.s3-website.us-east-2.amazonaws.com
